vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Jun 2003 20:35:32 -0000
vti_extenderversion:SR|4.0.2.6513
