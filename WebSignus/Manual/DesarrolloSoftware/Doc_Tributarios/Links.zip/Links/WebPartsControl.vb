Option Explicit On 
Option Strict On

Imports System.ComponentModel
Imports System.Web.UI
Imports System.Xml
Imports System.IO
Imports System

Namespace Lyquidity.UtilityLibrary.WebControls

    <DefaultProperty("Text"), ToolboxData("<{0}:WebPartsControl runat=server></{0}:WebPartsControl>")> _
    Public Class WebPartsControl
        Inherits System.Web.UI.WebControls.WebControl

        ' Property variables
        Private _XMLFile As String = "Links.xml"
        Private _DefaultPage As String = "http://www.google.com"
        Private _HTMLSubFolder As String = "HTML"         ' Location of the folder containing the Web Part snippets (relative to page on which control is used)
        Private _LinkFrame As String = "_Parent"

        ' XML variables use to retreve information from the l
        Private _FrameLinks As XmlNodeList
        Private _PopupLinks As XmlNodeList
        Private _doc As XmlDocument = New XmlDocument()

        ' Webpart snippet variables
        Private _FrameLink As String
        Private _PopupLink As String
        Private _LinkGroup As String
        Private _WebPart As String

        ' XML file tag names
        Private ReadOnly _LinksMemberTag As String = "/link"
        Private ReadOnly _PopupLinkGroupsMemberTag As String = "/group"

        Private _FrameLinksXPathQuery As String = "/links/framelinks"
        Private _PopupLinksXPathQuery As String = "/links/popuplinks"

        Private _FrameLinkMembersXPathQuery As String = _FrameLinksXPathQuery & _LinksMemberTag
        Private _PopupLinkGroupsXPathQuery As String = _PopupLinksXPathQuery & _PopupLinkGroupsMemberTag

#Region "Properties"

        Protected Overrides Sub OnInit(ByVal e As EventArgs)

            MyBase.OnInit(e)

            If Not Page.IsPostBack Then
                Me.XMLFile = Page.Request.QueryString("XMLFile")
                Me.DefaultPage = Page.Request.QueryString("DefaultPage")
            End If


        End Sub

        <Description("The name of the Default Page to use")> _
        Public Overridable Property DefaultPage() As String
            Get
                Return _DefaultPage
            End Get
            Set(ByVal Value As String)
                If TypeOf Value Is String Then
                    _DefaultPage = Value
                    If (Not _DefaultPage.StartsWith("http://")) Then
                        _DefaultPage = "http://" & _DefaultPage
                    End If
                End If
            End Set
        End Property

        <Bindable(True), Category("Behaviour"), DefaultValue("Links.xml"), Description("The name of the XML file to use")> _
        Public Overridable Property XMLFile() As String
            Get
                Return _XMLFile
            End Get
            Set(ByVal Value As String)
                If TypeOf Value Is String Then _XMLFile = Value
                If Not New FileInfo(context.Server.MapPath(_XMLFile)).Exists Then
                    Throw New ApplicationException(String.Format("The XML '{0}' cannot be found", _XMLFile))
                End If
            End Set
        End Property

        <Description("XPath Query to use to return the Link objects")> _
        Public Overridable Property FrameLinkLinksXPathQuery() As String
            Get
                Return _FrameLinksXPathQuery
            End Get
            Set(ByVal Value As String)
                _FrameLinksXPathQuery = Value
                _FrameLinkMembersXPathQuery = _FrameLinksXPathQuery & _LinksMemberTag
            End Set
        End Property

        <Description("XPath Query to use to return the LinkGroup objects")> _
        Public Overridable Property PopupLinksXPathQuery() As String
            Get
                Return _PopupLinksXPathQuery
            End Get
            Set(ByVal Value As String)
                _PopupLinksXPathQuery = Value
                _PopupLinkGroupsXPathQuery = _PopupLinksXPathQuery & _PopupLinkGroupsMemberTag
            End Set
        End Property

        <Description("Location of the web part snippets (relative to page)")> _
        Public Overridable Property HTMLSubFolder() As String
            Get
                Return _HTMLSubFolder
            End Get
            Set(ByVal Value As String)
                If Not New DirectoryInfo(context.Server.MapPath(Value)).Exists Then
                    Throw New ApplicationException(String.Format(" the subfolder {0} does not exist.", Value))
                End If
                _HTMLSubFolder = Value
            End Set
        End Property

        <Bindable(True), Category("Behaviour"), DefaultValue("_Parent"), Description("The frame to be used with FrameLink links.  The default is _Parent")> _
        Public Overridable Property LinkFrameName() As String
            Get
                Return _LinkFrame
            End Get
            Set(ByVal Value As String)
                If Not TypeOf Value Is String Then Throw New ApplicationException("The value of the link frame cannot be null")
                If Value.Equals(String.Empty) Then Throw New ApplicationException("The value of the link frame cannot be undefined")
                _LinkFrame = Value
            End Set
        End Property

#End Region

#Region "Methods"

        Protected Overrides Sub Render(ByVal writer As System.Web.UI.HtmlTextWriter)

	    Dim sRalativeCSSFolder as string = me._HTMLSubFolder.Replace("HTML", "")

            If _doc.OuterXml.Length = 0 Then BindToXML()

            writer.Write(String.Format("        <table cellpadding='0' cellspacing='0' " & _
                                       "width='150' id='PartTable{0}' class='clsPartContainer' style='behavior:url(" + sRalativeCSSFolder + "webparts/webparts.htc);' " & _
                                       "style='MARGIN-LEFT:10px; MARGIN-RIGHT:10px' border='0'>", Me.ID))
            writer.Write("	        <tr>")
            writer.Write("		        <td valign='top'>")
            writer.Write("		        	<LINK REL='stylesheet' TYPE='text/css' HREF='" + sRalativeCSSFolder + "css/ie4.css'></LINK>")
            writer.Write("		        	<LINK REL='stylesheet' TYPE='text/css' HREF='" + sRalativeCSSFolder + "webparts/ie.css'></LINK>")

            writer.Write(FramePart().Replace("%HTMLSubFolder", sRalativeCSSFolder))
	    writer.Write(LinksPart().Replace("%HTMLSubFolder", sRalativeCSSFolder))
            writer.Write(String.Format("                  <div class='storeUserData' id='oLayout'></div>", Me.ID))

            writer.Write("				</td>")
            writer.Write("			</tr>")
            writer.Write("			<tr>")
            writer.Write("				<td height='100%'><img src='" + sRalativeCSSFolder + "webparts/images/1x1.gif' height='100%'></td>")
            writer.Write("			</tr>")
            writer.Write("		</table>")

        End Sub

#End Region

#Region "Private Functions"

        Private Sub BindToXML()

            Const csErrorMessage As String = "No nodes could be found in the XML file '{0}' for the path {1}"

            Try

                ' Set up then XML
                _doc.Load(context.Server.MapPath(_XMLFile))

            Catch err As Exception
                Throw New ApplicationException(String.Format("An error occured reading the XML file {0}.  Error: {1}", _XMLFile, err.Message), err)
            End Try

            _FrameLinks = _doc.SelectNodes(_FrameLinkMembersXPathQuery)
            _PopupLinks = _doc.SelectNodes(_PopupLinksXPathQuery)

            'If _FrameLinks.Count = 0 Then
            '    Throw New ApplicationException(String.Format(csErrorMessage, _XMLFile, _FrameLinkMembersXPathQuery))
            'End If

            'If _PopupLinks.Count = 0 Then
            '    Throw New ApplicationException(String.Format(csErrorMessage, _XMLFile, _PopupLinkGroupsXPathQuery))
            'End If

            _FrameLink = GetFile("FrameLink")
            _PopupLink = GetFile("PopupLink")
            _LinkGroup = GetFile("LinkGroup")
            _WebPart = GetFile("WebPart")

        End Sub

        Private Function GetFile(ByVal sFile As String) As String

            Dim tr As TextReader

            Try

                tr = New StreamReader(context.Server.MapPath(_HTMLSubFolder & "/" & sFile & ".txt"))
                GetFile = tr.ReadToEnd
                tr.Close()

            Catch e As Exception

                Dim sErrorMessage As String = String.Format("The HTML fragment file '{0}' cannot be found", sFile)

                Try
                    HTMLSubFolder = _HTMLSubFolder
                Catch eHTML As ApplicationException
                    sErrorMessage += " because " & e.Message
                End Try

                Throw New ApplicationException(sErrorMessage)

            End Try

        End Function

        Private Function FrameLink(ByVal InfoLink As XmlNode) As String

            Dim sLink As String
	    Dim sTarget as String

            sLink = Link(_FrameLink, InfoLink)
	    sTarget = _LinkFrame
            Try : sTarget = InfoLink.Attributes("target").Value : Catch : : End Try
            sLink = sLink.Replace("%LinkFrame", sTarget)

            FrameLink = sLink

        End Function

        Private Function LinkGroup(ByVal Group As XmlNode) As String

            Dim GroupElement As XmlNode

            For Each GroupElement In Group.ChildNodes

                If GroupElement.Name.ToLower.Equals("link") Then
                    LinkGroup += PopupLink(GroupElement)
                Else
                    LinkGroup += FrameLink(GroupElement)
                End If

            Next
        End Function

        Private Function PopupLink(ByVal InfoLink As XmlNode) As String

            PopupLink = Link(_PopupLink, InfoLink)

        End Function

        Private Function Link(ByVal sLinkSnippet As String, ByVal InfoLink As XmlNode) As String

            Dim sLink As String
            Dim sAltText As String

            sLink = sLinkSnippet.Replace("%Name", InfoLink.Attributes("name").Value)
            sLink = sLink.Replace("%URL", InfoLink.Attributes("url").Value)
            Try : sAltText = InfoLink.Attributes("alttext").Value : Catch : sAltText = "" : End Try
            sLink = sLink.Replace("%Title", sAltText)

            Link = sLink

        End Function

        Private Function LinksPart() As String

            Dim Group As XmlNode
            Dim PopupLink As XmlNode
            Dim Groups As XmlNodeList
            Dim sGroup As String
            Dim sLinksPart As String
            Dim sTitle As String
            Dim sID As String

            For Each PopupLink In _PopupLinks

                Groups = PopupLink.SelectNodes("group")
                sLinksPart = ""

                For Each Group In Groups

                    sGroup = _LinkGroup.Replace("%GroupName", Group.Attributes("name").Value)
                    sGroup += LinkGroup(Group)

                    sLinksPart += sGroup

                Next

                Try
                    sID = PopupLink.Attributes("id").Value
                Catch ex As Exception
                    sID = Guid.NewGuid.ToString()
                End Try

                sTitle = PopupLink.Attributes("title").Value
                LinksPart += _WebPart.Replace("%Elements", sLinksPart).Replace("%WebPartTitle", sTitle).Replace("%id", sID)

            Next

        End Function

        Private Function FramePart() As String

            Dim Link As XmlNode
            Dim sLink As String
            Dim sElements As String
            Dim sTitle As String
            Dim sID As String

	    if _FrameLinks.Count = 0 then Return ""

            For Each Link In _FrameLinks

                sElements += FrameLink(Link)

            Next

            Try
                sID = _doc.SelectSingleNode(_FrameLinksXPathQuery).Attributes("id").Value
            Catch ex As Exception
                sID = Guid.NewGuid.ToString()
            End Try

            sTitle = _doc.SelectSingleNode(_FrameLinksXPathQuery).Attributes("title").Value
            FramePart = _WebPart.Replace("%Elements", sElements).Replace("%WebPartTitle", sTitle).Replace("%id", sID)

        End Function

#End Region

    End Class

End Namespace

